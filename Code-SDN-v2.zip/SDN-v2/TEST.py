for i in range(4,5):
    print(i)